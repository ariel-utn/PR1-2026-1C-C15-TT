#include <iostream>     /// YA VIENE EN C++
#include "funciones.h"  /// SON LOS CREADOS POR NOSOTROS -> " "

using namespace std;

/**

Hacer una funcion que reciba un numero entero por valor llamado dia y un string llamado nombreDia por referencia y le asigne el nombre correspondiente segun el numero de dia. Siendo 0 -> Domingo y 6 -> S�bado.
*/

/// DECLARACION
void diaSemana(int dia, string &nombreDia);

int main()
{
    string  palabras = "muchas palabras";
    char caracter = '#';

    cout << palabras << endl;
    cout << caracter << endl;



    ///guia5ejercicio1();

    return 0;
}


