#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

/// DECLARACION DE FUNCIONES
/// ARCHIVOS DE .H
int sumar(int n1, int n2);
float dividir(int n1, int n2);
int pedirNumero();
void mostrarValor(float numero);
void guia5ejercicio1();

#endif // FUNCIONES_H_INCLUDED
