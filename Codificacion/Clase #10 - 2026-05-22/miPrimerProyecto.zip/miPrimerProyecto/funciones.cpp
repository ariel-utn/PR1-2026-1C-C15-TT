#include <iostream>
#include "funciones.h"
using namespace std;


/// IMPLEMENTACION/DESARROLLO DE FUNCIONES
/// ARCHIVOS .CPP
int sumar(int n1, int n2)
{
    return n1 + n2;
}

float dividir(int n1, int n2)
{
    return (float)n1/n2;
}

int pedirNumero(){
    int n;
    cout << "Ingrese #: ";
    cin >> n;
    return n;
}

void mostrarValor(float numero){
    cout << "El valor es: " << numero << endl;
}

void guia5ejercicio1(){
    int num1, num2, num3, num4, suma1, suma2;
    float res;

    /// PIDO CUATRO NUMEROS
    num1 = pedirNumero();
    num2 = pedirNumero();
    num3 = pedirNumero();
    num4 = pedirNumero();

    /// SUMAR LOS DOS PRIMEROS
    suma1 = sumar(num1, num2);

    /// SUMAR EL 3RO Y 4TO
    suma2 = sumar(num3,num4);

    /// DIVIDIR LOS NUMEROS
    res = dividir(suma1, suma2);

    /// MOSTRAR RESULTADO
    mostrarValor(res);
}
