#ifndef JUEGO_H_INCLUDED
#define JUEGO_H_INCLUDED

#include <iostream>
using namespace std;

/// DECLARACION DE FUNCIONES
void jugar();

/// TIPO
/// NOMBRE
/// PARAMETROS
void determinarNaipe(int codigo, int &numero, string &nombrePalo);
int obtenerNumero(int rango);
void generarMano(int v[], int tam);
void mostrarMano(int v[], int tam);
void mostrarDados(int v[], int tam);

#endif // JUEGO_H_INCLUDED
