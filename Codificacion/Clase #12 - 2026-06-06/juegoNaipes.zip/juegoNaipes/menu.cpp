#include <iostream>
#include "menu.h"
#include "juego.h"

using namespace std;


void menuOpciones()
{
    cout << "**************" << endl;
    cout << " 1- JUGAR     " << endl;
    cout << " 2- ESTAD.    " << endl;
    cout << " 3- CREDITOS  " << endl;
    cout << " 4- SALIR     " << endl;
    cout << "**************" << endl;
    cout << "ELIGIR OPCION:" << endl;
}

void menuPrincipal()
{


    while(true)
    {
        int opcion;

        system("cls");
        menuOpciones();
        cin >> opcion;

        switch(opcion)
        {
        case 1:
        {
            ///
            jugar();
        }
        break;
        case 2:
        {

        }
        break;
        case 3:
        {

        }
        break;
        case 4:
        {
            cout << "Gracias por jugar!!!" << endl;
            return;
        }
        break;
        default:
            cout << "Opcion invalida"<< endl;

        }

    }
}


