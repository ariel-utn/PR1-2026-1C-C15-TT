#include <iostream>
#include "juego.h"
#include <chrono>

using namespace std;

void jugar()
{
    system("cls"); /// LIMPIAR PANTALLA

    cout << "BIENVENIDOS A ...." << endl;

    int const TAM = 5;
    int mano[TAM];
    generarMano(mano, TAM);
    /// mostrarMano(mano, TAM); /// JUEGO DE NAIPES
    mostrarDados(mano,TAM); /// JUEGO DE DADOS


    cout << endl;
    system("pause");
}

void determinarNaipe(int codigo, int &numero, string &nombrePalo)
{
    if( codigo <=10)
    {
        nombrePalo = "Espadas";
        numero = codigo;
    }
    else if( codigo <=20)
    {
        nombrePalo = "Bastos";
        numero = codigo -10;
    }

    else if( codigo <=30)
    {
        nombrePalo = "Copas";
        numero = codigo -20;
    }
    else
    {
        nombrePalo = "Oros";
        numero = codigo -30;
    }
    if(numero > 7)
    {
        ///numero = numero + 2;
        numero += 2;
    }
}

int obtenerNumero(int rango)
{
    return rand()%rango + 1;
}

void generarMano(int v[], int tam)
{
    for(int i =0; i < tam; i++)
    {
        /// v[i] = obtenerNumero(40);  /// JUEGO DE NAIPES
        v[i] = obtenerNumero(6);    /// JUEGO DE DADOS
    }
}

void mostrarMano(int v[], int tam)
{
    int numero;
    string nombre;
    for(int i =0; i < tam; i++)
    {
        /// cargo el el numero y palo de acuerdo al id
        determinarNaipe(v[i], numero, nombre);
        cout << numero << " " << nombre << endl;
    }
}

void mostrarDados(int v[], int tam){
    for(int i =0; i < tam; i++)
    {
        cout << v[i] <<  " ";
    }
}

