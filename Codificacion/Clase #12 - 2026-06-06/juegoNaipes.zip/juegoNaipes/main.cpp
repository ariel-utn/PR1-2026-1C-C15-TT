#include <iostream>
#include "menu.h"
#include <ctime>


using namespace std;

int main()
{
    /// SEMILLA
    srand(time(nullptr));

    menuPrincipal();

    return 0;
}
