#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED

/// PROTOTIPO DE FUNCION

void menuOpciones();
void menuPrincipal();

#endif // MENU_H_INCLUDED
